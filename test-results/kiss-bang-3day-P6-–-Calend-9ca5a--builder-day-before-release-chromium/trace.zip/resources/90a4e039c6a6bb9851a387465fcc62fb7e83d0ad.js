/** <Typesetter>.init **/

troikaDefine(
(e,t,r)=>e(t,r())
)