/** <Typesetter>.getTransferables **/

troikaDefine(
function getTransferables(e){let t=[];for(let r in e)e[r]&&e[r].buffer&&t.push(e[r].buffer);return t}
)