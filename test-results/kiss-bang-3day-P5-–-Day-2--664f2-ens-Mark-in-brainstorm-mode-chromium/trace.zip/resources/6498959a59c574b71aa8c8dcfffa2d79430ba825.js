/** <Typesetter>.init **/

troikaDefine(
e=>function(t){return new Promise(r=>{e.typeset(t,r)})}
)