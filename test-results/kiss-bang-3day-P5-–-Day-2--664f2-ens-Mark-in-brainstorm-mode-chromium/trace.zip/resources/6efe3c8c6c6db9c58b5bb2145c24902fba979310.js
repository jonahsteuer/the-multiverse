/** <Typr Font Parser>.init **/

troikaDefine(
(e,t,r)=>r(e(),t())
)